// scripts/seed.js
import { execSync } from "child_process";
import dotenv from "dotenv";

dotenv.config();

try {
  console.log("🌱 Exécution du seed SQL...");
  execSync(
    `mysql -h ${process.env.MYSQL_HOST} -P ${process.env.MYSQL_PORT} -u ${process.env.MYSQL_USER} -p${process.env.MYSQL_PASSWORD} ${process.env.MYSQL_DATABASE} < seed.sql`,
    { stdio: "inherit", shell: true }
  );
  console.log("✅ Données SQL injectées avec succès !");
} catch (err) {
  console.error("❌ Erreur lors du seed SQL :", err.message);
  process.exit(1);
}

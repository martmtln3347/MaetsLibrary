import { Router } from 'express';
import { register, login } from '../Controleur/user.controller.js';
import { authenticate } from "../middlewares/auth.js";


const router = Router();
router.post('/register', register);
router.post('/login', login);

export default router;

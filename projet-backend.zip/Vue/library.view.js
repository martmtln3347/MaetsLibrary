export function formatLibraryEntry(entry) {
  return {
    userId: entry.userId,
    gameId: entry.gameId,
    addedAt: entry.addedAt
  };
}

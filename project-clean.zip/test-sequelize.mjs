import sequelize from './config/sequelize.js';
console.log('Loaded type =', typeof sequelize);